# Originally written by miko
# Modified by dodslaser
. /home/osmc/.moonlight-osmc/moonlight-osmc.conf
sudo moonlight pair $GAMESTREAM_IP
sudo moonlight stream $GAMESTREAM_IP $MOONLIGHT_OPTS
